import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Lancamento } from '../lancamentos/lancamento.model';

@Injectable({
  providedIn: 'root'
})
export class LancamentoService {
  private apiUrl = 'http://localhost:3200/api/v1/lancamento';

  constructor(private http: HttpClient) { }

  getLancamentos(): Observable<Lancamento[]> {
    return this.http.get<Lancamento[]>(this.apiUrl);
  }

  getLancamento(id: number): Observable<Lancamento> {
    const url = `${this.apiUrl}/${id}`;
    return this.http.get<Lancamento>(url);
  }

  createLancamento(lancamento: Lancamento): Observable<Lancamento> {
    return this.http.post<Lancamento>(this.apiUrl, lancamento);
  }

  updateLancamento(lancamento: Lancamento): Observable<Lancamento> {
    const url = `${this.apiUrl}/${lancamento.id}`;
    return this.http.put<Lancamento>(url, lancamento);
  }

  deleteLancamento(id: number): Observable<void> {
    const url = `${this.apiUrl}/${id}`;
    return this.http.delete<void>(url);
  }
}

