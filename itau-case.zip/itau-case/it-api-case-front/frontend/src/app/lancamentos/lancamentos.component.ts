import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Lancamento } from './lancamento';
import { LancamentoService } from './lancamento.service';

@Component({
  selector: 'app-lancamento',
  templateUrl: './lancamento.component.html',
  styleUrls: ['./lancamento.component.css']
})
export class LancamentoComponent implements OnInit {
  lancamentoForm: FormGroup;
  lancamentos: Lancamento[];

  constructor(
    private formBuilder: FormBuilder,
    private lancamentoService: LancamentoService
  ) {}

  ngOnInit() {
    this.lancamentoForm = this.formBuilder.group({
      descricao: ['', Validators.required],
      valor: ['', Validators.required]
    });

    this.getLancamentos();
  }

  getLancamentos() {
    this.lancamentoService.getLancamentos().subscribe(lancamentos => {
      this.lancamentos = lancamentos;
    });
  }

  onSubmit() {
    if (this.lancamentoForm.invalid) {
      return;
    }

    const lancamento: Lancamento = {
      id: 0,
      descricao: this.lancamentoForm.value.descricao,
      valor: this.lancamentoForm.value.valor
    };

    this.lancamentoService.createLancamento(lancamento).subscribe(() => {
      this.getLancamentos();
      this.resetForm();
    });
  }

  resetForm() {
    this.lancamentoForm.reset();
  }
}
