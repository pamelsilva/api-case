export interface Lancamento {
  id?: string;
  idCategoria: string;
  description: string;
  date: string;
  value: number;
}
