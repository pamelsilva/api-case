export interface Categoria {
  id?: string;
  name: string;
}
