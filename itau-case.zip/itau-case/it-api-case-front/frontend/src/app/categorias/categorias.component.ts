import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Categoria} from './categoria.model';
import { Categoria } from './categoria';
import { CategoriaService } from './categoria.service';

@Component({
  selector: 'app-categoria',
  templateUrl: './categoria.component.html',
  styleUrls: ['./categoria.component.css']
})
export class CategoriaComponent implements OnInit {
  categoriaForm: FormGroup;
  categorias: Categoria[];

  constructor(
    private formBuilder: FormBuilder,
    private categoriaService: CategoriaService
  ) {}

  ngOnInit() {
    this.categoriaForm = this.formBuilder.group({
      nome: ['', Validators.required]
    });

    this.getCategorias();
  }

  getCategorias() {
    this.categoriaService.getCategorias().subscribe(categorias => {
      this.categorias = categorias;
    });
  }

  onSubmit() {
    if (this.categoriaForm.invalid) {
      return;
    }

    const categoria: Categoria = {
      id: 0,
      nome: this.categoriaForm.value.nome
    };

    this.categoriaService.createCategoria(categoria).subscribe(() => {
      this.getCategorias();
      this.resetForm();
    });
  }

  resetForm() {
    this.categoriaForm.reset();
  }
}



